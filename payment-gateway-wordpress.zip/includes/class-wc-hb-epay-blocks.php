<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!defined('ABSPATH')) {
    exit;
}

final class WC_HB_Epay_Blocks extends AbstractPaymentMethodType
{
    protected $name = 'hb_epay';

    public function initialize()
    {
        $this->settings = get_option('woocommerce_hb_epay_settings', array());
    }

    public function is_active()
    {
        return filter_var($this->get_setting('enabled', false), FILTER_VALIDATE_BOOLEAN);
    }

    public function get_payment_method_script_handles()
    {
        wp_register_script(
            'wc-payment-method-hb-epay',
            plugins_url('assets/js/hb-epay-blocks.js', HB_EPAY_PLUGIN_FILE),
            array(
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ),
            '1.0.2',
            true
        );

        return array('wc-payment-method-hb-epay');
    }

    public function get_payment_method_data()
    {
        return array(
            'title'       => $this->get_setting('title', 'HB epay'),
            'description' => $this->get_setting('description', ''),
            'supports'    => $this->get_supported_features(),
        );
    }

    public function get_supported_features()
    {
        $gateways = WC()->payment_gateways->payment_gateways();

        if (isset($gateways[$this->name]) && is_array($gateways[$this->name]->supports)) {
            return $gateways[$this->name]->supports;
        }

        return array('products');
    }
}
