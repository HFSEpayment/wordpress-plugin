(function () {
	if (!window.wc || !window.wc.wcBlocksRegistry || !window.wc.wcSettings) {
		return;
	}

	const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
	const { getPaymentMethodData, getSetting } = window.wc.wcSettings;
	const { decodeEntities } = window.wp.htmlEntities;
	const { createElement } = window.wp.element;

	const settings =
		typeof getPaymentMethodData === 'function'
			? getPaymentMethodData('hb_epay', {})
			: getSetting('hb_epay_data', {});

	const label = decodeEntities(settings.title || '') || 'HB epay';
	const description = decodeEntities(settings.description || '');

	const Label = function (props) {
		const PaymentMethodLabel = props.components && props.components.PaymentMethodLabel;

		if (PaymentMethodLabel) {
			return createElement(PaymentMethodLabel, { text: label });
		}

		return createElement('span', null, label);
	};

	const Content = function () {
		return createElement('div', { className: 'wc-hb-epay-description' }, description);
	};

	registerPaymentMethod({
		name: 'hb_epay',
		label: createElement(Label, null),
		content: createElement(Content, null),
		edit: createElement(Content, null),
		canMakePayment: function () {
			return true;
		},
		ariaLabel: label,
		supports: {
			features: settings.supports || ['products'],
		},
	});
})();
