<?php

/*
 * Plugin Name: WooCommerce HB Epay Payment Gateway 
 * Description: Take credit card payments on your store.
 * Author: Epay
 * Author URI: https://epayment.kz
 * Developers: Epay
 * Version: 1.0.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('HB_EPAY_PLUGIN_FILE', __FILE__);

add_action('before_woocommerce_init', 'hb_epay_declare_feature_compatibility');
add_action('plugins_loaded', 'hb_epay_init_gateway_class', 0);

if (did_action('woocommerce_blocks_loaded')) {
    hb_epay_register_blocks_support();
} else {
    add_action('woocommerce_blocks_loaded', 'hb_epay_register_blocks_support');
}

function hb_epay_declare_feature_compatibility()
{
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', HB_EPAY_PLUGIN_FILE, true);
    }
}

function hb_epay_register_blocks_support()
{
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        return;
    }

    require_once plugin_dir_path(HB_EPAY_PLUGIN_FILE) . 'includes/class-wc-hb-epay-blocks.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function ($payment_method_registry) {
            $payment_method_registry->register(new WC_HB_Epay_Blocks());
        }
    );
}

function hb_epay_init_gateway_class()
{
    if (!class_exists('WC_Payment_Gateway') || class_exists('WC_HB_Epay_Gateway')) {
        return;
    }

    class WC_HB_Epay_Gateway extends WC_Payment_Gateway
    {

        public $env;
        public $client_id;
        public $client_secret;
        public $terminal;

        public function __construct()
        {
            $this->id = 'hb_epay';
            $this->icon = '';
            $this->has_fields = true;
            $this->method_title = 'HB ePay Gateway';
            $this->method_description = 'Оплата безналичными';

            $this->supports = array(
                'products'
            );

            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');
            $this->env = $this->get_option('testmode');
            $this->client_id = $this->get_option('client_id');
            $this->client_secret = $this->get_option('client_secret');
            $this->terminal = $this->get_option('terminal');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
            add_action('woocommerce_api_' . $this->id, array($this, 'handle_callback'));

        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'label' => 'Enable HBepay Gateway',
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no'
                ),
                'title' => array(
                    'title' => 'Title',
                    'type' => 'text',
                    'description' => 'This controls the title which the user sees during checkout.',
                    'default' => 'HB epay',
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => 'Description',
                    'type' => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default' => 'Pay with your credit card HB payment gateway.',
                ),
                'testmode' => array(
                    'title' => 'Test mode',
                    'label' => 'Enable Test Mode',
                    'type' => 'checkbox',
                    'description' => 'Place the payment gateway in test mode using test API keys.',
                    'default' => 'no',
                    'desc_tip' => true,
                ),
                'client_id' => array(
                    'title' => 'Clien id',
                    'type' => 'text'
                ),
                'client_secret' => array(
                    'title' => 'Client secret',
                    'type' => 'text'
                ),
                'terminal' => array(
                    'title' => 'Terminal',
                    'type' => 'text'
                )
            );
        }


        public function generate_hbepay_form($order_id)
        {
            $widget = $this->pg_redirect($order_id);

            if (is_wp_error($widget)) {
                return '<p class="woocommerce-error">' . esc_html($widget->get_error_message()) . '</p>';
            }

            return $widget;
        }

        private function get_api_endpoints()
        {
            if ($this->env === 'yes') {
                return array(
                    // /epay2/oauth2/token больше не существует и отвечает 404.
                    'token'  => 'https://test-epay-oauth.epayment.kz/oauth2/token',
                    'widget' => 'https://test-epay.epayment.kz/payform/payment-api.js',
                );
            }

            return array(
                'token'  => 'https://epay-oauth.homebank.kz/oauth2/token',
                'widget' => 'https://epay.homebank.kz/payform/payment-api.js',
            );
        }

        private function get_invoice_id($order)
        {
            $invoice_id = str_pad((string) $order->get_id(), 6, '0', STR_PAD_LEFT);

            if (strlen($invoice_id) > 15) {
                $invoice_id = substr($invoice_id, -15);
            }

            return $invoice_id;
        }

        private function get_language_code()
        {
            $lang = strtolower(substr(get_bloginfo('language'), 0, 2));
            $map  = array(
                'ru' => 'rus',
                'kk' => 'kaz',
                'kz' => 'kaz',
                'en' => 'eng',
            );

            return isset($map[$lang]) ? $map[$lang] : 'rus';
        }

        public function pg_redirect($order_id)
        {
            $order = wc_get_order($order_id);

            if (!$order) {
                return new WP_Error('hb_epay_order', 'Заказ не найден.');
            }

            $endpoints = $this->get_api_endpoints();
            $invoice_id = $this->get_invoice_id($order);
            $amount = (float) $order->get_total();
            $currency = $order->get_currency() ? $order->get_currency() : 'KZT';
            $secret_hash = wp_generate_password(32, false);
            $post_link = WC()->api_request_url($this->id);
            $phone = preg_replace('/\D+/', '', (string) $order->get_billing_phone());
            $description = wp_strip_all_tags((string) $this->description);
            $description = function_exists('mb_strcut') ? mb_strcut($description, 0, 125, 'UTF-8') : substr($description, 0, 125);

            if ($description === '') {
                $description = sprintf('Order #%s', $order->get_id());
            }

            $order->update_meta_data('_hb_epay_secret_hash', $secret_hash);
            $order->update_meta_data('_hb_epay_invoice_id', $invoice_id);
            $order->save();

            $fields = array(
                'grant_type'      => 'client_credentials',
                'scope'           => 'webapi usermanagement email_send verification statement statistics payment',
                'client_id'       => $this->client_id,
                'client_secret'   => $this->client_secret,
                'invoiceID'       => $invoice_id,
                'secret_hash'     => $secret_hash,
                'amount'          => $amount,
                'currency'        => $currency,
                'terminal'        => $this->terminal,
                'postLink'        => $post_link,
                'failurePostLink' => $post_link,
            );

            $response = wp_remote_post(
                $endpoints['token'],
                array(
                    'timeout' => 30,
                    'headers' => array(
                        'Content-Type' => 'application/x-www-form-urlencoded',
                    ),
                    'body'    => $fields,
                )
            );

            if (is_wp_error($response)) {
                return new WP_Error(
                    'hb_epay_token',
                    'Не удалось получить токен ePay: ' . $response->get_error_message()
                );
            }

            $http_code = (int) wp_remote_retrieve_response_code($response);
            $body      = wp_remote_retrieve_body($response);
            $auth      = json_decode($body, true);

            if ($http_code !== 200 || empty($auth['access_token'])) {
                $api_message = '';

                if (is_array($auth)) {
                    $api_message = isset($auth['UserMessage']) ? $auth['UserMessage'] : (isset($auth['ClientMessage']) ? $auth['ClientMessage'] : '');
                }

                if ($api_message === '' && $body !== '') {
                    $api_message = wp_strip_all_tags($body);
                }

                return new WP_Error(
                    'hb_epay_token',
                    sprintf(
                        'Не удалось получить токен ePay (HTTP %d)%s',
                        $http_code,
                        $api_message ? ': ' . $api_message : ''
                    )
                );
            }

            $payment_object = array(
                'invoiceId'       => $invoice_id,
                'backLink'        => $this->get_return_url($order),
                'failureBackLink' => $order->get_cancel_order_url(),
                'autoBackLink'    => true,
                'postLink'        => $post_link,
                'failurePostLink' => $post_link,
                'language'        => $this->get_language_code(),
                'description'     => $description,
                'accountId'       => (string) $order->get_user_id(),
                'terminal'        => $this->terminal,
                'amount'          => $amount,
                'currency'        => $currency,
                'auth'            => $auth,
                'phone'           => $phone,
                'email'           => $order->get_billing_email(),
                'name'            => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            );

            return sprintf(
                '<p>%s</p><script src="%s"></script><script>halyk.pay(%s);</script>',
                esc_html__('Перенаправление на страницу оплаты…', 'woocommerce'),
                esc_url($endpoints['widget']),
                wp_json_encode($payment_object)
            );
        }

        public function process_payment($order_id)
        {

            $order = wc_get_order($order_id);

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true),
            );
        }

        public function thankyou_page($order_id)
        {
            $order = wc_get_order($order_id);

            if ($order && !$order->is_paid()) {
                $order->payment_complete();
            }
        }

        public function receipt_page($order)
        {
            $order_id = is_object($order) ? $order->get_id() : absint($order);
            echo $this->generate_hbepay_form($order_id);
        }

        public function handle_callback()
        {
            $raw  = file_get_contents('php://input');
            $data = json_decode($raw, true);

            if (!is_array($data)) {
                $data = wp_unslash($_POST);
            }

            $invoice_id = isset($data['invoiceId']) ? $data['invoiceId'] : '';
            $order_id   = absint($invoice_id);
            $order      = $order_id ? wc_get_order($order_id) : false;

            if (!$order) {
                status_header(404);
                exit;
            }

            $expected_hash = (string) $order->get_meta('_hb_epay_secret_hash');
            $received_hash = isset($data['secret_hash']) ? (string) $data['secret_hash'] : '';

            if ($expected_hash !== '' && ($received_hash === '' || !hash_equals($expected_hash, $received_hash))) {
                status_header(403);
                exit;
            }

            $is_success = (isset($data['code']) && $data['code'] === 'ok')
                || (isset($data['reasonCode']) && (int) $data['reasonCode'] === 0);

            if ($is_success) {
                $transaction_id = isset($data['id']) ? sanitize_text_field($data['id']) : '';
                $order->payment_complete($transaction_id);
                $order->add_order_note('HB ePay: оплата подтверждена.');
            } else {
                $reason = isset($data['reason']) ? $data['reason'] : 'Payment failed';
                $order->update_status('failed', 'HB ePay: ' . sanitize_text_field($reason));
            }

            echo 'OK';
            exit;
        }
    }
}

function hb_epay_add_gateway_class($gateways)
{
    $gateways[] = 'WC_HB_Epay_Gateway';
    return $gateways;
}

add_filter('woocommerce_payment_gateways', 'hb_epay_add_gateway_class');
